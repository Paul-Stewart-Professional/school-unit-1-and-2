import UIKit

func getArea(radius: Int) -> Double {
    var area = 3.14 * Double((radius * radius))
    return area
}

getArea(radius: 13)
