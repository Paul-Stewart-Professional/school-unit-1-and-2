var name: String
var age: Int
name = "Paul"
age = 17
let pi = 3.14
